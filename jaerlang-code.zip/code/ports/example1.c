int twice(int x){
  return 2*x;
}

int sum(int x, int y){
  return x+y;
}
